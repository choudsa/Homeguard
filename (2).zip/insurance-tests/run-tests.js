#!/usr/bin/env node
/**
 * run-tests.js
 * Run the full test suite. Pass --watch to re-run on app.html changes.
 *
 * Usage:
 *   node run-tests.js          # single run
 *   node run-tests.js --watch  # watch mode
 */

const { execSync, spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

const PLAYWRIGHT = path.resolve(__dirname, 'node_modules/.bin/playwright');
const PW_GLOBAL  = '/home/claude/.npm-global/lib/node_modules/playwright/cli.js';
const APP_FILE   = path.resolve(__dirname, 'app.html');
const CONFIG     = path.resolve(__dirname, 'playwright.config.js');

const playwrightCli = fs.existsSync(PLAYWRIGHT) ? PLAYWRIGHT : `node ${PW_GLOBAL}`;

function runTests() {
  console.log('\n' + '═'.repeat(60));
  console.log(`🧪  HomeGuard Insurance — Test Suite`);
  console.log(`📅  ${new Date().toLocaleString()}`);
  console.log('═'.repeat(60) + '\n');

  try {
    execSync(
      `${playwrightCli} test --config=${CONFIG}`,
      { stdio: 'inherit', env: { ...process.env, FORCE_COLOR: '1' } }
    );
    console.log('\n✅  All tests passed.\n');
  } catch {
    console.log('\n❌  Some tests failed. See output above.\n');
  }
}

const watchMode = process.argv.includes('--watch');

runTests();

if (watchMode) {
  console.log(`👀  Watching ${APP_FILE} for changes…\n`);
  let debounce;
  fs.watch(APP_FILE, () => {
    clearTimeout(debounce);
    debounce = setTimeout(() => {
      console.log('🔄  app.html changed — re-running tests…');
      runTests();
    }, 500);
  });
}
