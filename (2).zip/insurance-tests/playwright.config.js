const { defineConfig } = require('/home/claude/.npm-global/lib/node_modules/playwright/test.js');
const path = require('path');

module.exports = defineConfig({
  testDir: './tests',
  timeout: 15000,
  retries: 0,
  reporter: [
    ['list'],
    ['json', { outputFile: 'test-results.json' }],
  ],
  use: {
    launchOptions: {
      executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
      args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage'],
    },
    baseURL: `file://${path.resolve(__dirname, 'app.html')}`,
    headless: false,
  },
});
